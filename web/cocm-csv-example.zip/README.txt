CoCM caseload reporting: example data

The guide's example caseload (ten invented patients, March 2025) as one CSV per table.
Fill them in (or produce them from your systems) and add them to the calculator page:
https://spier-project.github.io/nys-omh-cocm-caseload-reporting/

- Keep the file names and the column headings as they are.
- Dates are YYYY-MM-DD. true or false for yes/no columns. Billing codes are separated by ;
- A table you don't need can be left with just its heading row.
- What each column holds, and the values it allows:
  https://github.com/SPiER-Project/nys-omh-cocm-caseload-reporting/blob/main/docs/reference/data-contract.md

Patient ids should be MRNs, the same in every file. Load your site's pseudonym key on
the calculator page before adding files if the results or tables will leave your site.
